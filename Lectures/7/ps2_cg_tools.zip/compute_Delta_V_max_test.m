clear;
close all;

m_o = 1000;             % Initial spacecraft mass [kg]
m_prop = 100;           % Maximum propellant mass [kg]
mu = 398600.5e9;        % Earth gravitational constant [m^3/s^2]
thruster.T = 10000;     % Bipropellant thrust [N]
thruster.I_sp = 312;    % I_sp [s]
r = 5000000;            % Radius [m]

compute_impulsive_Delta_V_max(m_o, m_prop, mu, r, thruster)
