clear;
close all;

mu = 398600.5e9;        % Earth gravitational constant [m^3/s^2]
r_A = 6567e3;           % Initial circular orbit [m]
r_B = 42160e3;          % Final circular orbit [m]

% Solution [3.95e3,18900]
[Delta_V,Delta_t] = compute_Hohmann_transfer(mu,r_A,r_B)
