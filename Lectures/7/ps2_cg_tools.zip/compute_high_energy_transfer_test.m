clear;
close all;
mu = 398600.5e9;        % Earth gravitational constant [m^3/s^2]
r_A = 6570e3;           % Initial circular orbit [m]
r_B = 42200e3;          % Final circular orbit [m]
%Delta_V_max  = 2.5752e+003;
Delta_V_max  = 3.5752e+003;


[Delta_V,Delta_t] = compute_high_energy_transfer(mu,r_A,r_B,Delta_V_max)