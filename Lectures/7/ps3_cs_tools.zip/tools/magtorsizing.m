function dipole = magtorsizing(t_aero,t_bfield,t_gg,t_solar)

% function magtorsizing.m sizes reaction wheels and cmgs:

% t_aero,t_bfield,t_gg,t_solar [N m]- disturbance torques from the environment

if(t_aero > t_bfield && t_aero > t_gg && t_aero > t_solar)
    t_d = t_aero;
elseif(t_bfield > t_aero && t_bfield > t_gg && t_bfield > t_solar)
    t_d = t_bfield;
elseif(t_gg > t_aero && t_gg > t_bfield && t_gg > t_solar)
    t_d = t_gg;
else
    t_d = t_solar;
end

B = 4.5e-15; % worst case Earth field

D = t_d/B;