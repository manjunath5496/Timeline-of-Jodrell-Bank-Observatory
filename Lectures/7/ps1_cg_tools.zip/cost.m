function c = cost(mass, price);
c = mass + price;


