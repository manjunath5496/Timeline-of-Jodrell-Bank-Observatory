
%for peak power tracking
%Xlow=0.6;
%Xhigh=0.8;
%for direct energy transfer
Xlow=0.65;
Xhigh=0.85;
%SMAD - direct more efficient by 5-7% b/c of lack of power converters

%transmission efficiency between battery and load
n=0.90; %example used in SMAD

%calculate amt of power that must be produced by SA, Psa
%SMAD 11-5 plus modifications
Psa=((Plow * Tlow/Xlow) + (Phigh*n*Thigh/Xhigh))/Thigh;


%use Sun normal to surface of cells
Po=max(P_available.intensity);

%betermine the beginning of life (Pbeol) power production capability
%inherent degradation
%this should be an input
%Id=0.77; %for testing purposes
%theta_worst=23.5*pi/180; % this needs to be found
%Pbol=Po*Id*cos(theta_worst);

%find end of life/cycle Power production capability (Peol)
%Peol=Pbol*Ld; %W/m^2
%Peol=end of Seung's code?

%find area of solar array
Asa=Psa/Peol; %m^2

%estimate mass of solar array
Mpanel=0.04*Psa; %kg

%estimate Number of batteries from Given battery capacity
%C_battery=Phigh*Thigh/(DOD*n*Nbatteries); %W hr
C_battery=0; %W-HR, for Amp-hr divide by bus voltage
C_battery=C_battery/28; %assumed 28 Volts as Bus Voltage
DOD=0.20;  %percentage, this should be an input from excel file
Nbatteries=Phigh*Thigh/(C_battery*DOD*n);

Mass_batt=0.1; %kg (this is an input from excel file)
Mass_batteries=Mass_batt*Mass_batt;



