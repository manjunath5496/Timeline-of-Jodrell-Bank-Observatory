figure(1); clf;
for i=1:storage_design_length
    for j=1:solar_design_length
        for k=1:SA_design_length
            plot(SAResult(i,j,k).SAMass,SAResult(i,j,k).STMass,'b.')
            hold on
        end
    end
end
hold off
xlabel('Solar array mass [kg]')
ylabel('Energy storage device mass [kg]')

figure(2); clf;
for i=1:storage_design_length
    for k=1:generation_design_length
        plot(RTGResult(i,k).Mass,RTGResult(i,k).Cost,'b.', RTGResult(i,k).MassINV,RTGResult(i,k).CostINV,'r.')
        hold on
    end
end
hold off
xlabel('Mass [kg]')
ylabel('Cost [$]')
title('Mass vs cost for RTG-based designs')

figure(3); clf;
for i=1:storage_design_length
    for j=1:solar_design_length
        for k=1:SA_design_length
            plot(SAResult(i,j,k).Mass,SAResult(i,j,k).Cost,'b.',SAResult(i,j,k).MassINV,SAResult(i,j,k).CostINV,'r.')
            hold on
        end
    end
end
hold off
xlabel('Mass [kg]')
ylabel('Cost [kg]')
title('Mass vs cost for solar array-based designs')

