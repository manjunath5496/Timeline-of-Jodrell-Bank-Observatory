function P = RTGPower(RTG, t);
% P = RTGPOWER(RTG, T)
%
% Inupts: 
%    RTG                Specification of the RTG
%    t                  Time length in a finite discret increments

initial_power = RTG.Power;                          % initial Power
P = initial_power * exp(-1/(87.74*365*24*3600)*t);  % assume Pu238 half life