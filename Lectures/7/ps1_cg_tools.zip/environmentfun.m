function [ENV] = environmentfun
% 	ENVIRONMENT MODULE
%
% 	-------------------------------------------------------------------
%	Global INPUT					VARIABLE NAME			UNIT
%
% 	-------------------------------------------------------------------
%	CONSTANTS						VARIABLE	NAME			UNIT
%
%	-------------------------------------------------------------------
%	INTERNAL OUTPUTS				VARIABLE NAME			UNIT
%	-------------------------------------------------------------------------
%	OUTPUTS							VARIABLE NAME			UNIT	
%
%	Sun Illumination Intensity      illuminationIntensity   W/m^2 
%	-------------------------------------------------------------------------


ENV.IlluminationIntensity = 1367;




