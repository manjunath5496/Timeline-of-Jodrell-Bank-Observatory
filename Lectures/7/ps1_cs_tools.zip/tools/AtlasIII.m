% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Atlas';
veh{i}.class = 'Atlas III';
veh{i}.country = 'USA';
veh{i}.provider = 'Lockheed Martin';
veh{i}.success_flight = 0; %# of flights%
veh{i}.total_flights = 0;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6; %g
veh{i}.max_lat_accel = 2; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 15; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 132; %dB
veh{i}.fairing_press = 7; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 19.4; %km
veh{i}.orbital_accu_incl = 0.02; %km
veh{i}.rate = 7; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 55; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'A';
 	veh{i}.upper_stage{j}.mass2leo = 8640; %kg
 	veh{i}.upper_stage{j}.mass2polar = 7121; %kg
 	veh{i}.upper_stage{j}.mass2SS = 7756; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 5671; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4037; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 105; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'B';
 	veh{i}.upper_stage{j}.mass2leo = 10718; %kg
 	veh{i}.upper_stage{j}.mass2polar = 9180; %kg
 	veh{i}.upper_stage{j}.mass2SS = 9239; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 5885; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4477; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 105; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m
