% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Pegasus';
veh{i}.class = 'Pegasus';
veh{i}.country = 'USA';
veh{i}.provider = 'OSC';
veh{i}.success_flight = 15; %# of flights%
veh{i}.total_flights = 18;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 11; %g
veh{i}.max_lat_accel = 4.7; %g
veh{i}.min_lat_freq = 20; %Hz
veh{i}.min_long_freq = 20; %Hz
veh{i}.shock = 3500; %g
veh{i}.acoustic = 119; %dB
veh{i}.fairing_press = 0; %kPa/s
veh{i}.max_aeroheating = 4542; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 28; %km
veh{i}.orbital_accu_incl = 0.05; %km
veh{i}.rate = 5.5; %# per year

veh{i}.site{1}.name = '#anywhere';
veh{i}.site{1}.min_incl = 0; %deg
veh{i}.site{1}.max_incl = 180; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'XL';
 	veh{i}.upper_stage{j}.mass2leo = 443; %kg
 	veh{i}.upper_stage{j}.mass2polar = 332; %kg
 	veh{i}.upper_stage{j}.mass2SS = 361; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 190; %kg
 	veh{i}.upper_stage{j}.mass2gto = 0; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 15; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 1.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 1.2; %m
