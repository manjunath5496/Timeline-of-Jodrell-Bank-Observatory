% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Atlas';
veh{i}.class = 'Atlas II';
veh{i}.country = 'USA';
veh{i}.provider = 'Lockheed Martin';
veh{i}.success_flight = 41; %# of flights%
veh{i}.total_flights = 41;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6; %g
veh{i}.max_lat_accel = 2; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 15; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 131; %dB
veh{i}.fairing_press = 7; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 19.4; %km
veh{i}.orbital_accu_incl = 0.02; %deg
veh{i}.rate = 7; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 55; %deg

veh{i}.site{2}.name = 'Vandenberg';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 120; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'A';
 	veh{i}.upper_stage{j}.mass2leo = 7316; %kg
 	veh{i}.upper_stage{j}.mass2polar = 6192; %kg
 	veh{i}.upper_stage{j}.mass2SS = 6074; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 3066; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 85; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 2.9; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'AS';
 	veh{i}.upper_stage{j}.mass2leo = 8618; %kg
 	veh{i}.upper_stage{j}.mass2polar = 7212; %kg
 	veh{i}.upper_stage{j}.mass2SS = 7225; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 3719; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 105; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m
