% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Ariane';
veh{i}.class = 'Ariane 4';
veh{i}.country = 'EU';
veh{i}.provider = 'Arianespace';
veh{i}.success_flight = 83; %# of flights%
veh{i}.total_flights = 86;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.5; %g
veh{i}.max_lat_accel = .2; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 31; %Hz
veh{i}.shock = 2000; %g
veh{i}.acoustic = 139; %dB
veh{i}.fairing_press = 3.2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 10000; %class
veh{i}.orbital_accu_alt = 3; %km
veh{i}.orbital_accu_incl = 0.054; %km
veh{i}.rate = 11; %# per year

veh{i}.site{1}.name = 'Guiana';
veh{i}.site{1}.min_incl = 5.2; %deg
veh{i}.site{1}.max_incl = 100.5; %deg

%-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'AR44L';
 	veh{i}.upper_stage{j}.mass2leo = 10200; %kg
 	veh{i}.upper_stage{j}.mass2polar = 8200; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 6485; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4770; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 125; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 6.5; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m
