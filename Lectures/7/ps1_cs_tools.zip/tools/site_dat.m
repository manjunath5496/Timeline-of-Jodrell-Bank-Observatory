% Site Database

% Latitude => North = (+)
% Longitude => East = (+)
%=============================
%=============================

i=1;
site{i}.name = 'KSC';
site{i}.country = 'USA';
site{i}.lat = 28.5; %[deg]
site{i}.long = -81.0; %[deg]
site{i}.max_incl = 57; %[deg]
site{i}.min_incl = 29; %[deg]

%=============================

i=i+1;
site{i}.name = 'Vandenberg';
site{i}.country = 'USA';
site{i}.lat = 34.4; %[deg]
site{i}.long = -120.35; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Wallops';
site{i}.country = 'USA';
site{i}.lat = 37.8; %[deg]
site{i}.long = -75.5; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Edwards';
site{i}.country = 'USA';
site{i}.lat = 35; %[deg]
site{i}.long = -118; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]


%=============================

i=i+1;
site{i}.name = 'Kwajalein';
site{i}.country = 'USA';
site{i}.lat = 9; %[deg]
site{i}.long = 167; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Plesetsk';
site{i}.country = 'Russia';
site{i}.lat = 62.8; %[deg]
site{i}.long = 40.1; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Baikonur';
site{i}.country = 'Russia';
site{i}.lat = 45.6; %[deg]
site{i}.long = 63.4; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Kapustin';
site{i}.country = 'Russia';
site{i}.lat = 48.4; %[deg]
site{i}.long = 45.8; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Svobodny';
site{i}.country = 'Russia';
site{i}.lat = 51.4; %[deg]
site{i}.long = 128.3; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Kourou';
site{i}.country = 'France';
site{i}.lat = 5.2; %[deg]
site{i}.long = -52.8; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Hammaguir';
site{i}.country = 'France';
site{i}.lat = 31.0; %[deg]
site{i}.long = -8.0; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]


%=============================

i=i+1;
site{i}.name = 'TNSC';
site{i}.country = 'Japan';
site{i}.lat = 30.4; %[deg]
site{i}.long = 131.0; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]

%=============================

i=i+1;
site{i}.name = 'Kagoshima';
site{i}.country = 'Japan';
site{i}.lat = 31.2; %[deg]
site{i}.long = 131.1; %[deg]
site{i}.max_incl = 0; %[deg]
site{i}.min_incl = 0; %[deg]
