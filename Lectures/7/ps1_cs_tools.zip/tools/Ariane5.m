% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Ariane';
veh{i}.class = 'Ariane 5';
veh{i}.country = 'EU';
veh{i}.provider = 'Arianespace';
veh{i}.success_flight = 1; %# of flights%
veh{i}.total_flights = 3;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.25; %g
veh{i}.max_lat_accel = .25; %g
veh{i}.min_lat_freq = 9; %Hz
veh{i}.min_long_freq = 31; %Hz
veh{i}.shock = 5000; %g
veh{i}.acoustic = 139; %dB
veh{i}.fairing_press = 3.2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 12; %km
veh{i}.orbital_accu_incl = 0.12; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Guiana';
veh{i}.site{1}.min_incl = 5.2; %deg
veh{i}.site{1}.max_incl = 100.5; %deg

%-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = '';
 	veh{i}.upper_stage{j}.mass2leo = 21500; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 16000; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 12000; %kg
 	veh{i}.upper_stage{j}.mass2gto = 7575; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 180; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 9.8; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 4.6; %m
