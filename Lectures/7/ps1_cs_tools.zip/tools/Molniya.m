% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Molniya';
veh{i}.class = 'Molniya';
veh{i}.country = 'Russia';
veh{i}.provider = 'Starsem';
veh{i}.success_flight = 263; %# of flights%
veh{i}.total_flights = 282;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.8; %g
veh{i}.max_lat_accel = 1; %g
veh{i}.min_lat_freq = 15; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 140; %dB
veh{i}.fairing_press = 2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 9; %km
veh{i}.orbital_accu_incl = 0.05; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Plesetsk';
veh{i}.site{1}.min_incl = 63; %deg
veh{i}.site{1}.max_incl = 90; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'M';
 	veh{i}.upper_stage{j}.mass2leo = 0; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 1500; %kg
 	veh{i}.upper_stage{j}.mass2gto = 0; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 40; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3; %m
