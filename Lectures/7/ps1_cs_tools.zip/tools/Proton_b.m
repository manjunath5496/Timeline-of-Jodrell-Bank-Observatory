% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Proton';
veh{i}.class = 'Proton';
veh{i}.country = 'Russia';
veh{i}.provider = 'ILS';
veh{i}.success_flight = 0; %# of flights%
veh{i}.total_flights = 0;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.3; %g
veh{i}.max_lat_accel = 1.35; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 8000; %g
veh{i}.acoustic = 132; %dB
veh{i}.fairing_press = 1.5; %kPa/s
veh{i}.max_aeroheating = 130; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 6; %km
veh{i}.orbital_accu_incl = 0.25; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Baikonur';
veh{i}.site{1}.min_incl = 52; %deg
veh{i}.site{1}.max_incl = 70; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'M';
 	veh{i}.upper_stage{j}.mass2leo = 21000; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 5500; %kg
 	veh{i}.upper_stage{j}.mass2geo = 2920; %kg
 	veh{i}.upper_stage{j}.cost = 112; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 6; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.8; %m
