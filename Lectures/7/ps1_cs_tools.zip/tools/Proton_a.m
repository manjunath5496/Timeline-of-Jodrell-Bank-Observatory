% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Proton';
veh{i}.class = 'Proton';
veh{i}.country = 'Russia';
veh{i}.provider = 'ILS';
veh{i}.success_flight = 229; %# of flights%
veh{i}.total_flights = 260;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.3; %g
veh{i}.max_lat_accel = 2.3; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 8000; %g
veh{i}.acoustic = 132; %dB
veh{i}.fairing_press = 1.5; %kPa/s
veh{i}.max_aeroheating = 130; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 6; %km
veh{i}.orbital_accu_incl = 0.5; %km
veh{i}.rate = 8; %# per year

veh{i}.site{1}.name = 'Baikonur';
veh{i}.site{1}.min_incl = 52; %deg
veh{i}.site{1}.max_incl = 73; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'K';
 	veh{i}.upper_stage{j}.mass2leo = 19760; %kg
 	veh{i}.upper_stage{j}.mass2polar = 3620; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 3620; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4910; %kg
 	veh{i}.upper_stage{j}.mass2geo = 1880; %kg
 	veh{i}.upper_stage{j}.cost = 98; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.2; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m
