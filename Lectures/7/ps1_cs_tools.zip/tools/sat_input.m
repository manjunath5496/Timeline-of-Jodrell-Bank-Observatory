%payload input
%put "-1" value to disable constraint
payload.name = 'Super Peeping Tom XXX';
payload.mass = 1; %[kg] wet weight
payload.volume = 1; %[m^3]
payload.diameter = 1; %[m]
payload.height = 1; %[m]
payload.orbit_type = 'leo'; %[orbit_type, leo, gto, geo, polar]
payload.inclination = 64; %[deg]
payload.launchfreq = 1; %[#launches/year]
payload.max_lat_accel = 2000; %[m/s^2]
payload.max_axial_accel = 1000; %[m/s^2]
payload.lat_freq = 15; %Hz
payload.long_freq = 35; %Hz
payload.acoustic = 10000000; %dB
payload.max_aeroheating = 1200; %W/m^2
payload.air_clean = 1000; %class
payload.orbital_accu_alt = 10; %km
payload.orbital_accu_incl = 10; %km


%***************************************
% Program Options                      *
%***************************************

% 1 for option/ 0 for no option
% You may only choose one option
payload.cost = 1;
payload.risk = 0;
payload.availiability = 0;
payload.pmargin = 0;
payload.absolute_cost = 0;