clear
clc

%loads payload data
sat_input


%Loads all launch vehicles

i=0;

Ariane4
Ariane5
AtlasII
AtlasIII
AtlasV
DeltaII
DeltaIV
Molniya
Pegasus
Proton_a
Proton_b
Soyuz

clear i j
