% Launch Vehicle Database

i=1;

veh{i}.family = 'Ariane';
veh{i}.class = 'Ariane 4';
veh{i}.country = 'EU';
veh{i}.provider = 'Arianespace';
veh{i}.success_flight = 83; %# of flights%
veh{i}.total_flights = 86;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.5; %g
veh{i}.max_lat_accel = .2; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 31; %Hz
veh{i}.shock = 2000; %g
veh{i}.acoustic = 139; %dB
veh{i}.fairing_press = 3.2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 10000; %class
veh{i}.orbital_accu_alt = 3; %km
veh{i}.orbital_accu_incl = 0.054; %km
veh{i}.rate = 11; %# per year

veh{i}.site{1}.name = 'Guiana';
veh{i}.site{1}.min_incl = 5.2; %deg
veh{i}.site{1}.max_incl = 100.5; %deg

%-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'AR44L';
 	veh{i}.upper_stage{j}.mass2leo = 10200; %kg
 	veh{i}.upper_stage{j}.mass2polar = 8200; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 6485; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4770; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 125; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 6.5; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m
    
    
i=i+1;

veh{i}.family = 'Ariane';
veh{i}.class = 'Ariane 5';
veh{i}.country = 'EU';
veh{i}.provider = 'Arianespace';
veh{i}.success_flight = 1; %# of flights%
veh{i}.total_flights = 3;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.25; %g
veh{i}.max_lat_accel = .25; %g
veh{i}.min_lat_freq = 9; %Hz
veh{i}.min_long_freq = 31; %Hz
veh{i}.shock = 5000; %g
veh{i}.acoustic = 139; %dB
veh{i}.fairing_press = 3.2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 12; %km
veh{i}.orbital_accu_incl = 0.12; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Guiana';
veh{i}.site{1}.min_incl = 5.2; %deg
veh{i}.site{1}.max_incl = 100.5; %deg

%-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = '';
 	veh{i}.upper_stage{j}.mass2leo = 21500; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 16000; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 12000; %kg
 	veh{i}.upper_stage{j}.mass2gto = 7575; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 180; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 9.8; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 4.6; %m
 
i=i+1;

veh{i}.family = 'Atlas';
veh{i}.class = 'Atlas II';
veh{i}.country = 'USA';
veh{i}.provider = 'Lockheed Martin';
veh{i}.success_flight = 41; %# of flights%
veh{i}.total_flights = 41;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6; %g
veh{i}.max_lat_accel = 2; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 15; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 131; %dB
veh{i}.fairing_press = 7; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 19.4; %km
veh{i}.orbital_accu_incl = 0.02; %km
veh{i}.rate = 7; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 55; %deg

veh{i}.site{2}.name = 'Vandenberg';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 120; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'A';
 	veh{i}.upper_stage{j}.mass2leo = 7316; %kg
 	veh{i}.upper_stage{j}.mass2polar = 6192; %kg
 	veh{i}.upper_stage{j}.mass2SS = 6074; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 3066; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 85; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 2.9; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'AS';
 	veh{i}.upper_stage{j}.mass2leo = 8618; %kg
 	veh{i}.upper_stage{j}.mass2polar = 7212; %kg
 	veh{i}.upper_stage{j}.mass2SS = 7225; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 3719; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 105; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m
    
i=i+1;

veh{i}.family = 'Atlas';
veh{i}.class = 'Atlas III';
veh{i}.country = 'USA';
veh{i}.provider = 'Lockheed Martin';
veh{i}.success_flight = 0; %# of flights%
veh{i}.total_flights = 0;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6; %g
veh{i}.max_lat_accel = 2; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 15; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 132; %dB
veh{i}.fairing_press = 7; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 19.4; %km
veh{i}.orbital_accu_incl = 0.02; %km
veh{i}.rate = 7; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 55; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'A';
 	veh{i}.upper_stage{j}.mass2leo = 8640; %kg
 	veh{i}.upper_stage{j}.mass2polar = 7121; %kg
 	veh{i}.upper_stage{j}.mass2SS = 7756; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 5671; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4037; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 105; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'B';
 	veh{i}.upper_stage{j}.mass2leo = 10718; %kg
 	veh{i}.upper_stage{j}.mass2polar = 9180; %kg
 	veh{i}.upper_stage{j}.mass2SS = 9239; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 5885; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4477; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 105; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m

i=i+1;

veh{i}.family = 'Atlas';
veh{i}.class = 'Atlas V';
veh{i}.country = 'USA';
veh{i}.provider = 'Lockheed Martin';
veh{i}.success_flight = 0; %# of flights%
veh{i}.total_flights = 0;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6; %g
veh{i}.max_lat_accel = 2; %g
veh{i}.min_lat_freq = 8; %Hz
veh{i}.min_long_freq = 15; %Hz
veh{i}.shock = 5000; %g
veh{i}.acoustic = 131; %dB
veh{i}.fairing_press = 7; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 19.4; %km
veh{i}.orbital_accu_incl = 0.02; %km
veh{i}.rate = 5; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 55; %deg

veh{i}.site{2}.name = 'Vandenberg';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 120; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = '400';
 	veh{i}.upper_stage{j}.mass2leo = 12500; %kg
 	veh{i}.upper_stage{j}.mass2polar = 10750; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 5000; %kg
 	veh{i}.upper_stage{j}.mass2geo = 1500; %kg
 	veh{i}.upper_stage{j}.cost = 90; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 4; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = '500';
 	veh{i}.upper_stage{j}.mass2leo = 20050; %kg
 	veh{i}.upper_stage{j}.mass2polar = 17000; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 8200; %kg
 	veh{i}.upper_stage{j}.mass2geo = 3750; %kg
 	veh{i}.upper_stage{j}.cost = 110; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5.5; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 4; %m
i=i+1;

veh{i}.family = 'Delta';
veh{i}.class = 'Delta II';
veh{i}.country = 'USA';
veh{i}.provider = 'Boeing';
veh{i}.success_flight = 78; %# of flights%
veh{i}.total_flights = 80;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6.65; %g
veh{i}.max_lat_accel = 2.5; %g
veh{i}.min_lat_freq = 15; %Hz
veh{i}.min_long_freq = 35; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 132.5; %dB
veh{i}.fairing_press = 3.45; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 10000; %ppm
veh{i}.orbital_accu_alt = 9.3; %km
veh{i}.orbital_accu_incl = 0.6; %km
veh{i}.rate = 11; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 60; %deg

veh{i}.site{2}.name = 'Vandenberg';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 145; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = '7320';
 	veh{i}.upper_stage{j}.mass2leo = 2865; %kg
 	veh{i}.upper_stage{j}.mass2polar = 2095; %kg
 	veh{i}.upper_stage{j}.mass2SS = 2435; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 1685; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1000; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 55; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 3.8; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 2.5; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = '7920';
 	veh{i}.upper_stage{j}.mass2leo = 5140; %kg
 	veh{i}.upper_stage{j}.mass2polar = 3895; %kg
 	veh{i}.upper_stage{j}.mass2SS = 4440; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 3220; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1870; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 60; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5.3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 2.7; %m
i=i+1;

veh{i}.family = 'Delta';
veh{i}.class = 'Delta IV';
veh{i}.country = 'USA';
veh{i}.provider = 'Boeing';
veh{i}.success_flight = 0; %# of flights%
veh{i}.total_flights = 0;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6.5; %g
veh{i}.max_lat_accel = 2.5; %g
veh{i}.min_lat_freq = 27; %Hz
veh{i}.min_long_freq = 30; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 133; %dB
veh{i}.fairing_press = 4.14; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %ppm
veh{i}.orbital_accu_alt = 8.6; %km
veh{i}.orbital_accu_incl = 0.06; %km
veh{i}.rate = 15; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 51; %deg

veh{i}.site{2}.name = 'Vandenberg';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 120; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'DIV M';
 	veh{i}.upper_stage{j}.mass2leo = 8600; %kg
 	veh{i}.upper_stage{j}.mass2polar = 6870; %kg
 	veh{i}.upper_stage{j}.mass2SS = 7700; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 6300; %kg
 	veh{i}.upper_stage{j}.mass2gto = 3900; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 90; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5.3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.8; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'DIV M+';
 	veh{i}.upper_stage{j}.mass2leo = 13600; %kg
 	veh{i}.upper_stage{j}.mass2polar = 10400; %kg
 	veh{i}.upper_stage{j}.mass2SS = 11800; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 9600; %kg
 	veh{i}.upper_stage{j}.mass2gto = 6120; %kg
 	veh{i}.upper_stage{j}.mass2geo = 2100; %kg
 	veh{i}.upper_stage{j}.cost = 110; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5.3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.8; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'DIV H';
 	veh{i}.upper_stage{j}.mass2leo = 25800; %kg
 	veh{i}.upper_stage{j}.mass2polar = 20800; %kg
 	veh{i}.upper_stage{j}.mass2SS = 23250; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 13200; %kg
 	veh{i}.upper_stage{j}.mass2gto = 10843; %kg
 	veh{i}.upper_stage{j}.mass2geo = 6100; %kg
 	veh{i}.upper_stage{j}.cost = 170; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 7.2; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 4.6; %m
i=i+1;

veh{i}.family = 'Molniya';
veh{i}.class = 'Molniya';
veh{i}.country = 'Russia';
veh{i}.provider = 'Starsem';
veh{i}.success_flight = 263; %# of flights%
veh{i}.total_flights = 282;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.8; %g
veh{i}.max_lat_accel = 1; %g
veh{i}.min_lat_freq = 15; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 140; %dB
veh{i}.fairing_press = 2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 9; %km
veh{i}.orbital_accu_incl = 0.05; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Plesetsk';
veh{i}.site{1}.min_incl = 63; %deg
veh{i}.site{1}.max_incl = 90; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'M';
 	veh{i}.upper_stage{j}.mass2leo = 0; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 1500; %kg
 	veh{i}.upper_stage{j}.mass2gto = 0; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 40; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3; %m
i=i+1;

veh{i}.family = 'Pegasus';
veh{i}.class = 'Pegasus';
veh{i}.country = 'USA';
veh{i}.provider = 'OSC';
veh{i}.success_flight = 15; %# of flights%
veh{i}.total_flights = 18;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 11; %g
veh{i}.max_lat_accel = 4.7; %g
veh{i}.min_lat_freq = 20; %Hz
veh{i}.min_long_freq = 20; %Hz
veh{i}.shock = 3500; %g
veh{i}.acoustic = 119; %dB
veh{i}.fairing_press = 0; %kPa/s
veh{i}.max_aeroheating = 4542; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 28; %km
veh{i}.orbital_accu_incl = 0.05; %km
veh{i}.rate = 5.5; %# per year

veh{i}.site{1}.name = '#anywhere';
veh{i}.site{1}.min_incl = 0; %deg
veh{i}.site{1}.max_incl = 180; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'XL';
 	veh{i}.upper_stage{j}.mass2leo = 443; %kg
 	veh{i}.upper_stage{j}.mass2polar = 332; %kg
 	veh{i}.upper_stage{j}.mass2SS = 361; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 190; %kg
 	veh{i}.upper_stage{j}.mass2gto = 0; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 15; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 1.1; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 1.2; %m
i=i+1;

veh{i}.family = 'Proton';
veh{i}.class = 'Proton';
veh{i}.country = 'Russia';
veh{i}.provider = 'ILS';
veh{i}.success_flight = 0; %# of flights%
veh{i}.total_flights = 0;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.3; %g
veh{i}.max_lat_accel = 1.35; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 8000; %g
veh{i}.acoustic = 132; %dB
veh{i}.fairing_press = 1.5; %kPa/s
veh{i}.max_aeroheating = 130; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 6; %km
veh{i}.orbital_accu_incl = 0.25; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Baikonur';
veh{i}.site{1}.min_incl = 52; %deg
veh{i}.site{1}.max_incl = 70; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'M';
 	veh{i}.upper_stage{j}.mass2leo = 21000; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 0; %kg
 	veh{i}.upper_stage{j}.mass2gto = 5500; %kg
 	veh{i}.upper_stage{j}.mass2geo = 2920; %kg
 	veh{i}.upper_stage{j}.cost = 112; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 6; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.8; %m
i=i+1;

veh{i}.family = 'Proton';
veh{i}.class = 'Proton';
veh{i}.country = 'Russia';
veh{i}.provider = 'ILS';
veh{i}.success_flight = 229; %# of flights%
veh{i}.total_flights = 260;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.3; %g
veh{i}.max_lat_accel = 2.3; %g
veh{i}.min_lat_freq = 10; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 8000; %g
veh{i}.acoustic = 132; %dB
veh{i}.fairing_press = 1.5; %kPa/s
veh{i}.max_aeroheating = 130; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 6; %km
veh{i}.orbital_accu_incl = 0.5; %km
veh{i}.rate = 8; %# per year

veh{i}.site{1}.name = 'Baikonur';
veh{i}.site{1}.min_incl = 52; %deg
veh{i}.site{1}.max_incl = 73; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'K';
 	veh{i}.upper_stage{j}.mass2leo = 19760; %kg
 	veh{i}.upper_stage{j}.mass2polar = 3620; %kg
 	veh{i}.upper_stage{j}.mass2SS = 0; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 3620; %kg
 	veh{i}.upper_stage{j}.mass2gto = 4910; %kg
 	veh{i}.upper_stage{j}.mass2geo = 1880; %kg
 	veh{i}.upper_stage{j}.cost = 98; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 4.2; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.7; %m
    

i=i+1;

veh{i}.family = 'Soyuz';
veh{i}.class = 'Soyuz';
veh{i}.country = 'Russia';
veh{i}.provider = 'Starsem';
veh{i}.success_flight = 644; %# of flights%
veh{i}.total_flights = 664;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.8; %g
veh{i}.max_lat_accel = 1; %g
veh{i}.min_lat_freq = 15; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 140; %dB
veh{i}.fairing_press = 2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 9; %km
veh{i}.orbital_accu_incl = 0.05; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Baikonur';
veh{i}.site{1}.min_incl = 52; %deg
veh{i}.site{1}.max_incl = 70; %deg

veh{i}.site{2}.name = 'Plesetsk';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 90; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'U';
 	veh{i}.upper_stage{j}.mass2leo = 6220; %kg
 	veh{i}.upper_stage{j}.mass2polar = 6000; %kg
 	veh{i}.upper_stage{j}.mass2SS = 3200; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 2700; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1350; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 50; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'ST';
 	veh{i}.upper_stage{j}.mass2leo = 7800; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 5000; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 4500; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1450; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 50; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 2.4; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.4; %m
