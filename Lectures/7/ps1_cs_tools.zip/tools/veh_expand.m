kk = 1;

for ii = [1:length(veh)]

  %## if generic vehicle can lift payload, add to database
  if ((veh{ii}.mass2leo+veh{ii}.mass2gto+veh{ii}.mass2geo+veh{ii}.mass2polar) ~= 0)
    veh_exp{kk} = veh{ii};
    kk = kk+1;
  end

  for jj = [1:length(veh{ii}.upper_stage)]
    veh_exp{kk} = veh{ii};
    veh_exp{kk}.class = [veh_exp{kk}.class '_' veh{ii}.upper_stage{jj}.us_name];

%% 		veh_exp{kk} = veh{ii}.upper_stage{jj};
    
		veh_exp{kk}.cost = veh{ii}.cost + veh{ii}.upper_stage{jj}.cost;
		veh_exp{kk}.mass2leo = veh{ii}.upper_stage{jj}.mass2leo;
		veh_exp{kk}.mass2gto = veh{ii}.upper_stage{jj}.mass2gto;
		veh_exp{kk}.mass2geo = veh{ii}.upper_stage{jj}.mass2geo;
		veh_exp{kk}.mass2polar = veh{ii}.upper_stage{jj}.mass2polar;

    veh_exp{kk} = rmfield(veh_exp{kk}, 'upper_stage');
		
		kk = kk+1;
  end 


end