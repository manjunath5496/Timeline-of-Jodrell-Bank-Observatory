

upper_stage(i).name = 'centaur';
upper_stage(i).thrust = ???
