%##################################
%## payload data

%specify a "-1" value to disable constraint

payload.name = 'Test Payload';
payload.mass = 6000; %[kg], total payload mass (spacecraft, adaptors, propellant)
payload.diameter = 3; %[m], payload diameter
payload.height = 3; %[m], payload height
payload.orbit_type = 'leo'; %orbit class // options: [leo, polar, sunsync, ss, gto, geo]
payload.inclination = 34; %[deg], desired orbit inclination
payload.launchfreq = 2; %[launches/year], launch frequency
payload.max_axial_accel = 8.5; %[g], max axial acceleration
payload.max_lat_accel = 2.2; %[g], max lateral acceleration
payload.lat_freq = 45; %[Hz], min lateral frequency
payload.long_freq = 30; %[Hz], min longitudinal frequency
payload.acoustic = 200; %[dB], noise intensity
payload.max_aeroheating = 1200; %[W/m^2], aeroheating after fairing deploy
payload.air_clean = 10000; %[class], air cleanliness class
payload.orbital_accu_alt = 20; %[km], allowable LEO insertion altitude error (+/-)
payload.orbital_accu_incl = 2; %[deg], allowable LEO insertion inclination error (+/-)



%##################################
%## Program Optimization Sorting Options

% 1 for category sort on // 0 for category sort off
% You may only enable one sort category at a time.

payload.cost = 0; %minimize cost
payload.risk = 0; %minimize risk
payload.pmargin = 0; %maximize margin
payload.availiability = 0; %maximize availability
payload.absolute_cost = 1; %minimize absolute cost