% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Soyuz';
veh{i}.class = 'Soyuz';
veh{i}.country = 'Russia';
veh{i}.provider = 'Starsem';
veh{i}.success_flight = 644; %# of flights%
veh{i}.total_flights = 664;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 4.8; %g
veh{i}.max_lat_accel = 1; %g
veh{i}.min_lat_freq = 15; %Hz
veh{i}.min_long_freq = 25; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 140; %dB
veh{i}.fairing_press = 2; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 100000; %class
veh{i}.orbital_accu_alt = 9; %km
veh{i}.orbital_accu_incl = 0.05; %km
veh{i}.rate = 9; %# per year

veh{i}.site{1}.name = 'Baikonur';
veh{i}.site{1}.min_incl = 52; %deg
veh{i}.site{1}.max_incl = 70; %deg

veh{i}.site{2}.name = 'Plesetsk';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 90; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = 'U';
 	veh{i}.upper_stage{j}.mass2leo = 6220; %kg
 	veh{i}.upper_stage{j}.mass2polar = 6000; %kg
 	veh{i}.upper_stage{j}.mass2SS = 3200; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 2700; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1350; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 50; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = 'ST';
 	veh{i}.upper_stage{j}.mass2leo = 7800; %kg
 	veh{i}.upper_stage{j}.mass2polar = 0; %kg
 	veh{i}.upper_stage{j}.mass2SS = 5000; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 4500; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1450; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 50; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 2.4; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 3.4; %m
