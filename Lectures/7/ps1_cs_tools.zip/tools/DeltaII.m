% Launch Vehicle Database

i=i+1;

veh{i}.family = 'Delta';
veh{i}.class = 'Delta II';
veh{i}.country = 'USA';
veh{i}.provider = 'Boeing';
veh{i}.success_flight = 78; %# of flights%
veh{i}.total_flights = 80;
veh{i}.stddwntime = 0.3; %years
veh{i}.surge = 1.15; %percentage
veh{i}.max_axial_accel = 6.65; %g
veh{i}.max_lat_accel = 2.5; %g
veh{i}.min_lat_freq = 15; %Hz
veh{i}.min_long_freq = 35; %Hz
veh{i}.shock = 4000; %g
veh{i}.acoustic = 132.5; %dB
veh{i}.fairing_press = 3.45; %kPa/s
veh{i}.max_aeroheating = 1135; %W/m^2
veh{i}.air_clean = 10000; %ppm
veh{i}.orbital_accu_alt = 9.3; %km
veh{i}.orbital_accu_incl = 0.6; %incl
veh{i}.rate = 11; %# per year

veh{i}.site{1}.name = 'KSC';
veh{i}.site{1}.min_incl = 28.5; %deg
veh{i}.site{1}.max_incl = 60; %deg

veh{i}.site{2}.name = 'Vandenberg';
veh{i}.site{2}.min_incl = 63; %deg
veh{i}.site{2}.max_incl = 145; %deg

  %-- Variants / Upper Stages --
  j=1;
 	veh{i}.upper_stage{j}.var_name = '7320';
 	veh{i}.upper_stage{j}.mass2leo = 2865; %kg
 	veh{i}.upper_stage{j}.mass2polar = 2095; %kg
 	veh{i}.upper_stage{j}.mass2SS = 2435; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 1685; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1000; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 55; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 3.8; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 2.5; %m

  j=j+1;
 	veh{i}.upper_stage{j}.var_name = '7920';
 	veh{i}.upper_stage{j}.mass2leo = 5140; %kg
 	veh{i}.upper_stage{j}.mass2polar = 3895; %kg
 	veh{i}.upper_stage{j}.mass2SS = 4440; %kg
 	veh{i}.upper_stage{j}.mass2sunsync = 3220; %kg
 	veh{i}.upper_stage{j}.mass2gto = 1870; %kg
 	veh{i}.upper_stage{j}.mass2geo = 0; %kg
 	veh{i}.upper_stage{j}.cost = 60; %million dollars
 	veh{i}.upper_stage{j}.fairingheight = 5.3; %m
 	veh{i}.upper_stage{j}.fairingdiameter = 2.7; %m
