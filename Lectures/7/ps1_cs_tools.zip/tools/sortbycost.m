[sorted] = sortbycost(qualified_vehicles);

max = qualified_vehicles{1}.cost; 
for i = [2:length(qualified_vehicles)]
    if(qualified_vehicles{i}.cost > max)
        bestveh{m} = qualified_vehicles{i};
    end
end

for i = [1:length(qualified_vehicles)]
    if(qualified_vehicles{i}.cost == max)
        qualified_vehicles{i} = [];
        break;
    end
end

new_list = sortbycost(qualified_vehicles);

new_list{length(new_list)+1} = bestveh;
sorted = new_list;