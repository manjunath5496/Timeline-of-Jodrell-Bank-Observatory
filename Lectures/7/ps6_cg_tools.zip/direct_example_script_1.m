%## Test

% clc

  mu_sun = 1.327e20; %[m^3/s^2], Sun gravity constant
  r_earth = 1.49598e11; %[m], Earth-Sun average distance
  r_mars = 2.28e11; %[m], Mars-Sun average distance

% mu_sun = 3.986e14; %[m^3/s^2], Sun gravity constant
% r_earth = 6570000; %[m], Earth-Sun average distance
% r_mars = 42200000; %[m], Mars-Sun average distance

% mu_sun = 3.986e14; %[m^3/s^2], Sun gravity constant
% r_earth = 6378000; %[m], Earth-Sun average distance
% r_mars = 6570000; %[m], Mars-Sun average distance

  a = 1.052*(r_earth+r_mars)/2;

 
[deltaV1, deltaV2, T_flight, time, r_mag, nu_time] = transfer_direct(r_earth,r_mars,a,mu_sun);
  
   deltaV1
   deltaV2
   deltaV1+deltaV2
   T_flight/60/60/24
   
%    figure(4)
%    plot(time,r_mag)
   
   figure(5)
   polar([0:pi/20:2*pi],r_mars*ones(1,41),'r')
   hold on
   polar([0:pi/20:2*pi],r_earth*ones(1,41),'g')
   polar(nu_time,r_mag,'b')
   hold off


