function [txt] = eng_read

	[num, txt] = xlsread('engine_data.xls');
	
	for ii = 2:length(num)
        txt{ii,1} = num(ii,1);
        txt{ii,2} = num(ii,2);
        txt{ii,3} = num(ii,3);
        txt{ii,4} = num(ii,4);
	end
