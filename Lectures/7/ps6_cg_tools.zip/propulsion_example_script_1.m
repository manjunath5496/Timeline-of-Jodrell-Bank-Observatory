deltaV = 4300; %[m/s]
m_dry = 10000; %[kg]

[m_fuel, m_prop_sys, m_wet, eng_name] = propulsion_module(deltaV, m_dry)
