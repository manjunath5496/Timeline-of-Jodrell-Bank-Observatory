function lambda = inclination2magnetic_latitude(I)

lambda = atan(tan(I)/2);